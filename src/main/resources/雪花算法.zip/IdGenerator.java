package com.fwxgx.shopservice.common;

import com.fwxgx.misc.common.util.SnowFlake;

import java.util.UUID;

/**
 * ID生成器.
 *
 * @author linfq
 * @date 2019/6/11 17:02
 */
public class IdGenerator {

    /**
     * 雪花算法.
     */
    private static final SnowFlake SNOW_FLAKE = new SnowFlake(1, 8);

    /**
     * 不可实例化.
     */
    private IdGenerator() {}

    /**
     * 生成id.
     *
     * @return
     */
    public static long generateId() {
        return SNOW_FLAKE.nextId();
    }


    /**
     * 生成简单UUID，无中杠.
     *
     * @return
     */
    public static String simpleUUID() {
        return UUID.randomUUID().toString().replace("-", "");
    }

}
